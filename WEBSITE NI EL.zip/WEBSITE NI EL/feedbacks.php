<?php
    session_start();

    if (!isset($_SESSION['loggedin']) || !$_SESSION['loggedin']) {
        header("Location: login.php");
        exit;
    }

    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to my Website - Portfolio</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
        <link rel="stylesheet" href="css/feedbacks.css">
        <link rel="stylesheet" href="css/transition.css">

    </head>

    <body>

        <header>
            <a href="index.html">Home</a>
            <a href="aboutme.html">About Me</a>
            <a href="education.html">Education Background</a>
            <a href="contact.html">Contact</a>
            <a href="feedbacks.php">Feedbacks</a>
            <a href="logout.php">Logout</a>
        </header>

    <div id="content">
        <div class="container">

        <div class="transparent-box">
            <h2>Leave a Comment</h2>
            <form action="process_feedback.php" method="post">
                <div class="form-group">
                    <textarea class="form-control container-item" id="feedback" name="feedback" rows="3" placeholder="Enter Comment" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary container-item">Submit</button>
            </form>
        </div>

        <div class="feedbacks-container">
            <div class="transparent-box ">
                <?php

                include "database.php";

                $stmt = $conn->prepare("SELECT feedbacks.feedback, feedbacks.created_at, tbl_users.first_name, tbl_users.last_name FROM feedbacks JOIN tbl_users ON feedbacks.user_id = tbl_users.id ORDER BY feedbacks.created_at DESC");
                $stmt->execute();
                $result = $stmt->get_result();

                $feedbacks = $result->fetch_all(MYSQLI_ASSOC);
                ?>

                <h2>Comments</h2>
                <ul class="list-group">
                    <?php foreach ($feedbacks as $feedback): ?>
                        <li>
                            <p><strong><?php echo htmlspecialchars($feedback['first_name']) . ' ' . htmlspecialchars($feedback['last_name']); ?></strong></p>
                            <p><?php echo htmlspecialchars($feedback['feedback']); ?></p>
                            <small>Posted on <?php echo date('F j, Y, g:i a', strtotime($feedback['created_at'])); ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

        </div>

        </div>
    </div>

    <script src="script.js"></script>

    </body>

    </html>
