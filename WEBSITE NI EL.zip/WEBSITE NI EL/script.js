document.addEventListener('DOMContentLoaded', function() {
    var content = document.getElementById('content');
    content.classList.add('visible'); 
});
