<?php

$servername = "sql208.infinityfree.com";
$username = "if0_36115018";
$password = "DhWRdpT2wDx";
$dbname = "if0_36115018_db_elrenecalacal";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
